package adapter;

import scale.Scaleable;

/*
 * Assignment 4: we have added the scale package
 * which contains an interface Scaleable
 */
public class CreateAuto extends ProxyAutomobile implements BuildAuto, UpdateAuto, ChooseAuto, scale.Scaleable {

}